/**
 * 
 */
/**
 * 
 */
module NumberGame {
}